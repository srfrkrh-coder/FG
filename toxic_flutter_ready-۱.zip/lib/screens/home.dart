import 'package:flutter/material.dart';
import '../widgets/galaxy_bg.dart';
import 'game_screen.dart';
import 'chat_screen.dart';
import 'package:audioplayers/audioplayers.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int tabIndex = 0;
  AudioPlayer? _player;
  bool _playing = false;

  @override
  void initState() {
    super.initState();
    _player = AudioPlayer();
    // try autoplay
    _tryPlay();
  }

  Future<void> _tryPlay() async {
    try {
      await _player!.play(AssetSource('assets/bgmusic.mp3'));
      setState(() { _playing = true; });
    } catch (e) {
      // autoplay may be blocked, wait for user interaction
      setState(() { _playing = false; });
    }
  }

  @override
  void dispose() {
    _player?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        const GalaxyBackground(),
        Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            title: const Text('𝚃𝚘𝚡𝚒𝚌'),
            actions: [
              IconButton(
                icon: Icon(_playing ? Icons.music_note : Icons.play_arrow),
                onPressed: () async {
                  if(_playing) {
                    await _player?.pause();
                    setState(() { _playing = false; });
                  } else {
                    await _player?.play(AssetSource('assets/bgmusic.mp3'));
                    setState(() { _playing = true; });
                  }
                },
              )
            ],
          ),
          body: SafeArea(
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ChoiceChip(label: const Text('چت'), selected: tabIndex==0, onSelected: (_){ setState(()=>tabIndex=0); }),
                    const SizedBox(width:10),
                    ChoiceChip(label: const Text('بازی'), selected: tabIndex==1, onSelected: (_){ setState(()=>tabIndex=1); }),
                  ],
                ),
                Expanded(
                  child: tabIndex==0 ? const ChatScreen() : const GameScreen(),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
