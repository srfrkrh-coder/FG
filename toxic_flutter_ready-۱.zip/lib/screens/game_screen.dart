import 'package:flutter/material.dart';
import 'dart:math';
import 'package:supabase_flutter/supabase_flutter.dart';

class GameScreen extends StatefulWidget {
  const GameScreen({Key? key}) : super(key: key);
  @override State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  String letter = '-';
  int timeLeft = 30;
  Timer? _timer;
  bool active = false;
  List<String> categories = ['اسم','فامیل','شهر','حیوان','اشیاء','میوه','رنگ'];
  Map<String, TextEditingController> controllers = {};

  @override
  void initState(){
    super.initState();
    for(var c in categories) controllers[c]=TextEditingController();
  }

  @override
  void dispose(){
    _timer?.cancel();
    for(var c in controllers.values) c.dispose();
    super.dispose();
  }

  String randomLetter(){
    final letters = 'ابتثجچحخدذرزسشصضطظعغفقکگلمنوهی'.split('');
    final r = Random();
    return letters[r.nextInt(letters.length)];
  }

  void startRound() async {
    setState(()=>letter=randomLetter());
    setState(()=>timeLeft=30);
    setState(()=>active=true);
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds:1), (t){
      setState(()=> timeLeft--);
      if(timeLeft<=0){
        t.cancel();
        setState(()=>active=false);
        // scoring can be added calling Supabase RPC
      }
    });
    // Optional: insert into Supabase games table (placeholder)
    try {
      final res = await Supabase.instance.client.from('games').insert({'letter':letter, 'is_active':true});
    } catch (e) {
      // ignore
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(12.0),
      child: Column(
        children: [
          Text(letter, style: const TextStyle(fontSize:48, color: Color(0xFFa020f0))),
          Text('⏱️ $timeLeft ثانیه', style: const TextStyle(color:Color(0xFF7ee7ff))),
          const SizedBox(height:12),
          Expanded(
            child: GridView.count(
              crossAxisCount: 2,
              childAspectRatio: 3,
              crossAxisSpacing: 8,
              mainAxisSpacing: 8,
              children: categories.map((c){
                return TextField(controller: controllers[c], decoration: InputDecoration(labelText:c, filled:true, fillColor: Colors.black26));
              }).toList(),
            ),
          ),
          Row(children: [
            ElevatedButton(onPressed: active ? null : startRound, child: const Text('شروع راند')),
            const SizedBox(width:10),
            ElevatedButton(onPressed: active ? (){ /* submit answers to Supabase */ } : null, child: const Text('ثبت پاسخ‌ها')),
          ],)
        ],
      ),
    );
  }
}
