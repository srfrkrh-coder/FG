import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({Key? key}) : super(key: key);
  @override State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final client = Supabase.instance.client;
  final TextEditingController _ctrl = TextEditingController();
  List messages = [];

  @override
  void initState(){
    super.initState();
    loadMessages();
    client.from('messages').on(SupabaseEventTypes.insert, (payload) {
      setState(()=> messages.add(payload.newRecord));
    }).subscribe();
  }

  Future<void> loadMessages() async {
    final res = await client.from('messages').select().order('created_at', ascending: true).limit(200).execute();
    if(res.error==null) setState(()=> messages = res.data ?? []);
  }

  Future<void> sendMessage() async {
    final txt = _ctrl.text.trim();
    if(txt.isEmpty) return;
    // filter links
    if(txt.contains(RegExp(r'https?://|www\.'))) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('ارسال لینک مجاز نیست')));
      return;
    }
    try {
      await client.from('messages').insert({'username':'کاربر','text':txt});
      _ctrl.clear();
    } catch (e) {}
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(child: ListView.builder(itemCount: messages.length, itemBuilder: (c,i){
          final m = messages[i];
          return ListTile(title: Text('${m['username']}: ${m['text']}'), subtitle: Text(m['created_at'] ?? ''));
        })),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(children: [
            Expanded(child: TextField(controller: _ctrl, decoration: const InputDecoration(hintText:'پیام...'))),
            IconButton(icon: const Icon(Icons.send), onPressed: sendMessage)
          ]),
        )
      ],
    );
  }
}
