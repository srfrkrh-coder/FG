import 'package:flutter/material.dart';
import 'dart:math';

class GalaxyBackground extends StatefulWidget {
  const GalaxyBackground({Key? key}) : super(key: key);
  @override State<GalaxyBackground> createState() => _GalaxyBackgroundState();
}

class _GalaxyBackgroundState extends State<GalaxyBackground> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  @override
  void initState(){
    super.initState();
    _ctrl = AnimationController(vsync:this, duration: const Duration(seconds:20))..repeat();
  }
  @override
  void dispose(){ _ctrl.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (context, child) {
        return CustomPaint(
          painter: _GalaxyPainter(_ctrl.value),
          size: MediaQuery.of(context).size,
        );
      },
    );
  }
}

class _GalaxyPainter extends CustomPainter {
  final double t;
  _GalaxyPainter(this.t);
  @override
  void paint(Canvas canvas, Size size){
    final paint = Paint()..style=PaintingStyle.fill;
    final rnd = Random(1234);
    for(int i=0;i<120;i++){
      final x = rnd.nextDouble()*size.width;
      final y = rnd.nextDouble()*size.height;
      final r = rnd.nextDouble()*1.8 + (sin(t*6.28 + i)*0.6 + 0.6);
      paint.color = Colors.white.withOpacity(0.02 + rnd.nextDouble()*0.2);
      canvas.drawCircle(Offset(x,y), r, paint);
    }
  }
  @override bool shouldRepaint(covariant _GalaxyPainter old) => true;
}
