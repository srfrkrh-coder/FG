# Toxic Galaxy - Flutter (Codemagic-ready)

این پروژه اسکلت یک اپ Flutter است که برای Codemagic آماده شده. تغییرات درخواست‌شده:
- تم کهکشانی متحرک
- افکت نئون برای عنوان 𝚃𝚘𝚡𝚒𝚌
- پخش خودکار موسیقی پس‌زمینه با fallback به لمس کاربر
- بازی اسم‌فامیل ساده با تایمر 30 ثانیه
- چت عمومی پایه (Supabase placeholder)

## آماده‌سازی قبل از بیلد
1. در `lib/services/supabase_config.dart` مقدار SUPABASE_URL و SUPABASE_KEY را با مقادیر خودت جایگزین کن یا در Codemagic به عنوان متغیر محیطی قرار بده.
2. اگر می‌خواهی موزیک متفاوتی استفاده کنی، فایل `assets/bgmusic.mp3` را جایگزین کن.
3. در Codemagic، پروژه را از فایل ZIP آپلود کن یا از GitHub متصل کن و یک build Android تهیه کن.

## بیلد در Codemagic
- وارد https://codemagic.io شو.
- پروژه جدید بساز و ZIP را آپلود کن یا repo را وصل کن.
- انتخاب کن Android/Flutter build و Start build کن.
- پس از اتمام، APK قابل دانلود خواهد بود.

