# Family Name Game - Design Guidelines

## Design Approach
**Reference-Based Approach**: Inspired by Clash Royale's gaming interface combined with modern chat applications (Discord, Telegram) for real-time communication features.

## Core Design Principles
1. **Gaming-First Interface**: Immersive, playful, and engaging with game-like interactions
2. **Clear Hierarchy**: Distinct zones for game area, chat, and user management
3. **Real-time Feedback**: Visual indicators for all live updates and player actions
4. **Spatial Depth**: Layered UI elements creating depth perception typical of gaming interfaces

## Typography System

**Primary Font**: Supercell-style bold, rounded sans-serif (e.g., Lilita One, Fredoka One via Google Fonts)
**Secondary Font**: Clean, readable sans-serif for chat and data (e.g., Inter, Poppins)

**Scale**:
- Neon branding: text-6xl to text-8xl, bold, uppercase tracking-wider
- Game headers: text-3xl to text-4xl, font-bold
- Section titles: text-xl to text-2xl, font-semibold
- Body/chat text: text-base, font-normal
- Metadata/timestamps: text-sm, font-light

## Layout System

**Spacing Primitives**: Tailwind units of 2, 4, 6, and 8 (p-2, m-4, gap-6, h-8)
**Consistent padding**: p-4 for cards, p-6 for panels, p-8 for main containers

**Grid Structure**:
```
Desktop: Three-column layout
- Left sidebar (w-64): Online users list with avatars and status indicators
- Center area (flex-1): Game board and input area
